const mysql = require('mysql');

const connection = mysql.createConnection({
    host : '192.168.11.20',
    user : 'suhas',
    password : 'suhas',
    database : 'nodeProject'
})

connection.connect(function(err) {
    console.log(err);
    if (err) {
      return console.error('error: ' + err.message);
    }
    console.log('Connected to the MySQL server.');
});

module.exports = connection