const studentValidation = require('./studentValidation');
const AuthValidator = require('./auth.validation');

module.exports = {
    studentValidation,
    AuthValidator
}