const joi = require('joi');

exports.register = joi.object({
    name : joi.string().min(3).max(30).required(),
    email : joi.string().email().required(),
    password : joi.string().pattern(new RegExp(/^[a-zA-Z0-9!@#$%^&*]{6,16}$/)).required(),
});

exports.login = joi.object({
    email : joi.string().email().required(),
    password : joi.string().pattern(new RegExp(/^[a-zA-Z0-9!@#$%^&*]{6,16}$/)).required(),
});