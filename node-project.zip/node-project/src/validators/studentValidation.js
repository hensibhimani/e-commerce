const Joi = require('joi');

exports.students = Joi.object({
    name : Joi.string().min(3).max(30).required(),
    email : Joi.string().email().required(),
    password : Joi.string().pattern(new RegExp(/^[a-zA-Z0-9!@#$%^&*]{6,16}$/)).required(),
    submit : Joi.allow()
});