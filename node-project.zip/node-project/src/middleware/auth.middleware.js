const { jwtServices } = require('../services/index');

const verifyToken = (req, res, next) =>{
    const token = req.header("Authorization")&&req.header("Authorization").replace("Bearer", "");
    if(!token) return res.status(401).json({ error : "Access denied ! Please provide token "}); 
    try{
        const decoded = jwtServices.verifyAccessToken(token);
        if(decoded.success == false) {
            return res.status(401).json({ message: decoded.error });
        }
        next();
    }
    catch(err){
        res.status(401).json({ error: "Invalid token "});
    }
}

module.exports = { verifyToken };