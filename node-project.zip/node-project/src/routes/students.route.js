
const express = require('express');

const routes = express.Router();

const controller = require('../controller');
const ctr = new controller.studentModule.StudentRecord();

const { studentValidation } = require('../validators');
const { validate }  = require('../middleware/validate.middleware');


const con = require('../config/connection');

routes.get('/',ctr.home);

routes.post('/insertRecord', validate(studentValidation.students), ctr.insertRecord);

routes.get('/showRecord',ctr.showRecord);

// routes.delete ===> use API //
routes.delete('/deleteRecord/:id',ctr.deleteRecord);

routes.get('/updateRecord/:id',ctr.updateRecord);

routes.post('/EditRecord',ctr.EditRecord);

module.exports = routes;