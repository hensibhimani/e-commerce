const express = require('express');
const routes = express.Router(); 

const controller = require('../controller');
const { AuthValidator } = require("../validators");
const {validate} = require("../middleware/validate.middleware");
const { valid } = require('joi');

const ctr = new controller.AuthModule.authController()

routes.post("/register", validate(AuthValidator.register), ctr.register);

routes.post("/login", validate(AuthValidator.login), ctr.login);

module.exports = routes;