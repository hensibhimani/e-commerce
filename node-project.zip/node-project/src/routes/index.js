const express = require('express'); 
const routes = express.Router();

routes.use("/student",require("./students.route"));
routes.use("/AuthUser",require("./auth.route"));

module.exports = routes