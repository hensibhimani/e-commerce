const { func } = require('joi');
const con = require('../config/connection');
const jwt = require('jsonwebtoken');
const { Passwordbcrypt } = require('../services/bcrypt.services');
const bodyParser = require('body-parser');

class StudentRecord {
    constructor() { }
    async home(req, res) {
        try {
            return res.render('home');
        }
        catch (err) {
            console.log(err);
        }
    }

    async insertRecord(req, res) {
        try {
            const bpass = await Passwordbcrypt(req.body.password)

            const sql = `INSERT INTO project(name, email ,password) VALUES ( '${req.body.name}' ,'${req.body.email}','${bpass}' )`;
            con.query(sql, function (err, result) {
                if (err) throw err;
                res.send('Record insert successfully');
            });
        }
        catch (err) {
            console.log(err);
        }
    }

    async showRecord(req, res) {
        try {
            con.query('select * from project', function (err, rows) {
                if (err) {
                    res.send(err);
                    // render to views/users
                    // res.send(rows) // use API //
                    res.send('rows', { data: '' });
                } else {
                    // render to views/users
                    res.render('read', { data: rows });
                }
            });
        }
        catch (err) {
            res.send(err);
        }
    }

    async deleteRecord(req, res) {
        try {
            let id = req.params.id;
            con.query('delete from project where id=' + id, function (err, result) {
                if (err) {
                    console.log(err);
                    res.redirect('/showRecord');
                }
                else {
                    res.send('user successfully delete id');
                    res.redirect('/showRecord');
                }
            })
        }
        catch (err) {
            console.log(err);
        }
    }

    async updateRecord(req, res) {
        try {
            let id = req.params.id;

            con.query('select * from project where id=' + id, function (err, rows, fields) {

                let result = Object.values(JSON.parse(JSON.stringify(rows)));

                if (err) {
                    if (rows.length <= 0) {
                        console.log("User not found with id=" + id)
                        res.redirect('/showRecord');
                    }
                } else {
                    // console.log("=====================================");
                    // console.log(rows[0].name);
                    // console.log("=====================================");
                    res.render('update', {
                        id: rows[0].id,
                        name: rows[0].name,
                        email: rows[0].email,
                        password: rows[0].password,
                    })
                }
            })
        }
        catch (err) {
            console.log(err);
        }
    }

    async EditRecord(req, res) {
        try {
            console.log(req.body);
            let id = req.body.id;
            let name = req.body.name;
            let email = req.body.email;
            let password = req.body.password

            if (name.length === 0 || email.length === 0 || password.length === 0) {
                errors = true;

                console.log('Please Enter name and email and password');
                req.send('update', {
                    name: name,
                    email: email,
                    password: password
                })
            }

            var form_data = {
                name: name,
                email: email,
                password: password
            }
            
            con.query('update project set ? where id=' + id, form_data, function (err, result) {
                if (err) {
                    console.log('error', err);
                    req.render('update', {
                        name: form_data.name,
                        email: form_data.email,
                        password: form_data.password
                    })
                } else {
                    res.send('User Successfully update');
                    res.redirect('/showRecord');
                }
            })
        }
        catch (err) {
            console.log(err);
        }
    }
}

module.exports = { StudentRecord };