const { func } = require('joi');
const con = require('../config/connection');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const { Passwordbcrypt, passwordCompare } = require('../services/bcrypt.services');
const secretKey = process.env.JWT_SECRET_KEY;

class authController {
    constructor() { }
    async register(req, res) {
        try {
            const bpass = await Passwordbcrypt(req.body.password)
            // console.log(bpass);
            const sql = `INSERT INTO project(name, email ,password) VALUES ( '${req.body.name}' ,'${req.body.email}','${bpass}' )`;
            con.query(sql, function (err, result) {
                if (err) throw err;
                res.send('Student register successfully');
            });
        }
        catch (err) {
            console.log(err);
            return res.status(500).send("Something went wrong!");
        }
    }

    async login(req, res) {
        try {
            const query = await `select * from project where email="${req.body.email}"`;
            con.query(query, async function (err, result) {
                const pass = await passwordCompare(req.body.password, result[0].password)
                if (pass == true) {
                    let data = {
                        id : result[0].id,
                        name : result[0].name,
                        email : result[0].email
                    }
                    const token = jwt.sign(data, secretKey);
                    return res.json({ 'satatus': 200, 'msg': 'login successfully', token });
                }
                else {
                    return res.json({ 'status': 500, 'msg': 'Token not valid' })
                }
            })
        }
        catch (err) {
            console.log(err);
            return res.status(500).send('Something wrong went!');
        }
    }
}

module.exports = { authController };