const studentModule = require('./student.controller');
const AuthModule = require('./auth.controller');

module.exports = {
    studentModule,
    AuthModule
}