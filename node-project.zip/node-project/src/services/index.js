module.exports = {
    jwtServices : require('./jwt.services'),
    bcryptServices : require('./bcrypt.services')
}