const { func } = require('joi');
const jwt = require('jsonwebtoken');

const secretKey = process.env.JWT_SECRET_KEY;

function getAccessToken(payload) {
    try{
        const options = { expiresIn : "1d" };
        return jwt.sing(payload, secretKey, options);
    }
    catch(err){
        throw new Error("Failed to generate access token");
    }
}

function verifyAccessToken(token){
    try {
        const decoded = jwt.verify(token, secretKey);
        return { success: true, date: decoded };
    }
    catch(err){
        return { success: false, error: "Failed to verify access token "};
    }
}

module.exports = { getAccessToken, verifyAccessToken };