const bcrypt = require('bcrypt');

const saltRound = 10;

const Passwordbcrypt = async (password)=>{
    // console.log(password);
    const pass = await bcrypt.hash(password, saltRound);
    console.log(pass);
    return pass;
};

const passwordCompare = async (password, oldPass) =>{
    // console.log(password, oldPass)
    const passCheck = await bcrypt.compare(password, oldPass);
    return passCheck;
}

module.exports = {
    Passwordbcrypt,
    passwordCompare
};