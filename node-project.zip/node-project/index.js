const express = require('express');
const port = 8081;
const app = express();
const path = require('path');
const session = require('express-session');
const flash = require('express-flash-message');
const bodyParser = require('body-parser');
require('dotenv').config();
// const Flash  require('js-flash-message');

app.set('view engine', 'ejs');
app.set('views',path.join(__dirname, 'src/views'));

app.use(express.json());

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended: true}));

// app.use(
//     session({
//       secret: 'secret',
//       resave: false,
//       saveUninitialized: true,
//       cookie: {
//         maxAge: 1000 * 60 * 60 * 24 * 7,
//       },
//     })
//   );
// app.use(flash());

app.use('/',require('./src/routes'));

app.listen(port, function(err){
    if(err){
        console.log(err);
    }
    else{
        console.log('server is runing on',port);
    }
})